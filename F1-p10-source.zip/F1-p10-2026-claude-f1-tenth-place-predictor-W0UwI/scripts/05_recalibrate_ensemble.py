#!/usr/bin/env python3
"""
Step 5 – Recalibrate WeightedEnsemble weights via leave-one-year-out CV.

For each hold-out year in CV_YEARS:
  1. Train all BASE models on the remaining years.
  2. Evaluate every base model race-by-race on the hold-out year.
  3. Record average fantasy pts/race per model.

Weights are then derived from the per-model CV scores using softmax scaling:
  weight(m) = exp(score(m) / T) / sum_k exp(score(k) / T)
  then rescaled so the best model = MAX_WEIGHT.

Temperature T controls spread:
  T → ∞  : equal weights (ignore performance differences)
  T → 0  : winner-take-all
  T = 3.0: moderate discrimination (default)

Outputs
-------
  results/cv_recalibration.csv   – per-model per-year CV fantasy scores
  results/cv_weights.csv         – derived weights vs old weights comparison
  src/models.py                  – ENSEMBLE_WEIGHTS updated in-place
  models/ensemble.joblib         – rebuilt with new weights
"""

import argparse
import logging
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import FEATURE_COLS, MODELS_DIR, PROCESSED_DIR, RESULTS_DIR, TARGET_COL
from src.models import (
    ENSEMBLE_WEIGHTS,
    MULTICLASS_CLFS,
    WeightedEnsemble,
    load_all,
    predict_race,
    train_all,
)
from src.scoring import fantasy_pts, calculate_regret, max_possible_pts

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

SEP = "─" * 72

# ── CV configuration ──────────────────────────────────────────────────────────
CV_YEARS       = list(range(2018, 2025))  # 7 hold-out folds (2018–2024)
SOFTMAX_TEMP   = 3.0   # temperature for weight derivation
MAX_WEIGHT     = 5.0   # best model is rescaled to this weight
MIN_WEIGHT     = 0.1   # floor to avoid zero-weighting any model


def _cv_fold(train_df: pd.DataFrame, eval_df: pd.DataFrame, eval_year: int) -> list[dict]:
    """Train base models on train_df, evaluate on eval_df, return per-race rows."""
    logger.info("  Fold %d — training on %d years …", eval_year, train_df["year"].nunique())
    fitted = train_all(train_df, force=True)
    # Drop ensemble from fitted — we're calibrating it, not evaluating it
    base_fitted = {k: v for k, v in fitted.items() if not isinstance(v, WeightedEnsemble)}

    rows = []
    for (yr, rnd), grp in eval_df.groupby(["year", "round"]):
        actual_map = dict(zip(grp["driver_id"], grp[TARGET_COL]))
        race_max = max_possible_pts(actual_map)
        _, picks = predict_race(grp, base_fitted)
        for model_name, pick_driver in picks.items():
            actual_pos = actual_map.get(pick_driver, 20)
            pts = fantasy_pts(actual_pos)
            rows.append({
                "cv_year":    eval_year,
                "round":      rnd,
                "model":      model_name,
                "picked":     pick_driver,
                "actual_pos": actual_pos,
                "fantasy_pts": pts,
                "regret":     race_max - pts,
            })
    return rows


def softmax_weights(
    scores: dict[str, float],
    temp: float = SOFTMAX_TEMP,
    max_w: float = MAX_WEIGHT,
    min_w: float = MIN_WEIGHT,
) -> dict[str, float]:
    """
    Convert per-model CV scores to weights using softmax scaling.

    Steps:
      1. Softmax over scores with temperature T.
      2. Rescale linearly so the best model gets max_w.
      3. Apply min_w floor.
      4. Round to 2 d.p. for readability.
    """
    models = list(scores.keys())
    vals   = np.array([scores[m] for m in models], dtype=float)

    # Softmax
    shifted = vals - vals.max()          # numerical stability
    soft    = np.exp(shifted / temp)
    soft    /= soft.sum()

    # Rescale to [min_w, max_w]
    soft_max = soft.max()
    rescaled = soft * (max_w / soft_max)
    rescaled = np.maximum(rescaled, min_w)

    weights = {m: round(float(w), 2) for m, w in zip(models, rescaled)}
    return weights


def update_models_py(new_weights: dict[str, float]) -> None:
    """Patch ENSEMBLE_WEIGHTS in src/models.py with the calibrated values."""
    path = Path(__file__).parent.parent / "src" / "models.py"
    src  = path.read_text()

    # Find and replace the ENSEMBLE_WEIGHTS block
    import re
    pattern = r"(ENSEMBLE_WEIGHTS:\s*dict\[str,\s*float\]\s*=\s*\{)[^}]+(})"
    lines = [f'    "{m}": {w},' for m, w in sorted(new_weights.items(), key=lambda x: -x[1])]
    replacement = r"\g<1>\n" + "\n".join(lines) + "\n" + r"\g<2>"
    new_src = re.sub(pattern, replacement, src, count=1)

    if new_src == src:
        logger.warning("ENSEMBLE_WEIGHTS pattern not matched — manual update needed")
        return

    path.write_text(new_src)
    logger.info("Updated ENSEMBLE_WEIGHTS in src/models.py")


def main() -> None:
    parser = argparse.ArgumentParser(description="Recalibrate ensemble weights via LOYO-CV")
    parser.add_argument("--temp",      type=float, default=SOFTMAX_TEMP,
                        help=f"Softmax temperature (default {SOFTMAX_TEMP})")
    parser.add_argument("--max-weight", type=float, default=MAX_WEIGHT,
                        help=f"Max weight for best model (default {MAX_WEIGHT})")
    parser.add_argument("--no-patch",  action="store_true",
                        help="Skip patching models.py (just show proposed weights)")
    args = parser.parse_args()

    # ── load full training data ───────────────────────────────────────────────
    train_path = PROCESSED_DIR / "features_2010_2024.parquet"
    if not train_path.exists():
        logger.error("Training data not found: %s", train_path); sys.exit(1)

    all_df = pd.read_parquet(train_path)
    logger.info("Loaded training data: %d rows, years %s",
                len(all_df), sorted(all_df["year"].unique()))

    # ── LOYO-CV ───────────────────────────────────────────────────────────────
    logger.info("\n%s", SEP)
    logger.info("  Leave-One-Year-Out CV  |  folds: %s", CV_YEARS)
    logger.info(SEP)

    all_rows = []
    for eval_year in CV_YEARS:
        tr = all_df[all_df["year"] != eval_year]
        te = all_df[all_df["year"] == eval_year]
        fold_rows = _cv_fold(tr, te, eval_year)
        all_rows.extend(fold_rows)
        fold_df = pd.DataFrame(fold_rows)
        fold_summary = fold_df.groupby("model")["fantasy_pts"].mean().sort_values(ascending=False)
        logger.info("  %d results  |  best: %s (%.2f pts)",
                    eval_year, fold_summary.index[0], fold_summary.iloc[0])

    cv_df = pd.DataFrame(all_rows)
    cv_path = RESULTS_DIR / "cv_recalibration.csv"
    cv_df.to_csv(cv_path, index=False)
    logger.info("\nSaved CV results → %s", cv_path)

    # ── per-model aggregate CV scores ─────────────────────────────────────────
    cv_summary = (
        cv_df.groupby("model")
        .agg(
            n_races     =("fantasy_pts", "count"),
            avg_pts     =("fantasy_pts", "mean"),
            avg_regret  =("regret",      "mean"),
            exact_p10   =("actual_pos",  lambda x: (x == 10).sum()),
            std_pts     =("fantasy_pts", "std"),
        )
        .sort_values("avg_pts", ascending=False)
        .reset_index()
    )
    cv_summary["exact_pct"] = (cv_summary["exact_p10"] / cv_summary["n_races"] * 100).round(1)

    logger.info("\n%s", SEP)
    logger.info("  CV Results (avg fantasy pts/race across %s)", CV_YEARS)
    logger.info(SEP)
    logger.info("\n%s", cv_summary[["model","avg_pts","avg_regret","exact_pct","std_pts"]].to_string(index=False))

    # ── derive new weights ────────────────────────────────────────────────────
    score_map = dict(zip(cv_summary["model"], cv_summary["avg_pts"]))
    new_weights = softmax_weights(score_map, temp=args.temp, max_w=args.max_weight)

    # Build comparison table
    all_models = sorted(set(list(ENSEMBLE_WEIGHTS.keys()) + list(new_weights.keys())))
    weight_rows = []
    for m in all_models:
        weight_rows.append({
            "model":      m,
            "cv_avg_pts": round(score_map.get(m, float("nan")), 3),
            "old_weight": ENSEMBLE_WEIGHTS.get(m, 0.0),
            "new_weight": new_weights.get(m, 0.0),
            "delta":      round(new_weights.get(m, 0.0) - ENSEMBLE_WEIGHTS.get(m, 0.0), 2),
        })
    weight_df = pd.DataFrame(weight_rows).sort_values("new_weight", ascending=False)

    weights_path = RESULTS_DIR / "cv_weights.csv"
    weight_df.to_csv(weights_path, index=False)

    logger.info("\n%s", SEP)
    logger.info("  Proposed Weight Update  (T=%.1f, max_w=%.1f)", args.temp, args.max_weight)
    logger.info(SEP)
    logger.info("\n%s", weight_df.to_string(index=False))

    if args.no_patch:
        logger.info("\n--no-patch set: skipping models.py and ensemble.joblib update")
        return

    # ── patch models.py ───────────────────────────────────────────────────────
    logger.info("\nPatching ENSEMBLE_WEIGHTS in src/models.py …")
    update_models_py(new_weights)

    # ── rebuild ensemble with new weights ─────────────────────────────────────
    logger.info("Rebuilding ensemble.joblib with new weights …")
    fitted_full = train_all(all_df, force=False)   # loads cached base models (no retrain)
    base = {k: v for k, v in fitted_full.items() if not isinstance(v, WeightedEnsemble)}
    ens = WeightedEnsemble(base_models=base, weights=new_weights)
    joblib.dump(ens, MODELS_DIR / "ensemble.joblib")
    logger.info("Saved → models/ensemble.joblib")

    logger.info("\n%s", SEP)
    logger.info("  Done. Run scripts/04_evaluate_2025.py to compare on 2025 season.")
    logger.info(SEP)


if __name__ == "__main__":
    main()
