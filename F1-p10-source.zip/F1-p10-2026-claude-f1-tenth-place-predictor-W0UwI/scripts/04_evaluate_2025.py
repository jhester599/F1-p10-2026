#!/usr/bin/env python3
"""
Step 4 – Evaluate trained models against the 2025 F1 season.

Evaluation is built around two complementary metrics:

  Fantasy Points  – how many points the model's pick actually earned.
  Regret          – (Max possible pts that race) − (pts the model scored).
                    Regret = 0 means the model picked the optimal driver in
                    hindsight.  High regret means it left points on the table.

Baselines included for comparison
----------------------------------
  naive_p10_grid  – always pick the driver who starts from grid position 10.
  naive_p10_champ – always pick the driver ranked 10th in the championship.
  oracle          – theoretical upper bound (picks optimal driver every race).

Outputs
-------
  results/eval_2025_picks.csv       – per-race picks, scores & regret per model
  results/eval_2025_summary.csv     – aggregate stats per model (sorted by avg pts)
  results/eval_2025_by_circuit.csv  – per-circuit breakdown
  results/eval_2025_plots/          – optional matplotlib charts
"""
import argparse
import logging
import sys
from pathlib import Path

import pandas as pd
import numpy as np

sys.path.insert(0, str(Path(__file__).parent.parent))

from config import (
    EVAL_YEAR, FEATURE_COLS, PROCESSED_DIR, RESULTS_DIR, TARGET_COL,
)
from src.models import load_all, predict_race
from src.scoring import (
    calculate_regret,
    evaluate_predictions,
    fantasy_pts,
    get_race_score,
    max_possible_pts,
    score_table,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

SEPARATOR = "─" * 80


def _naive_grid_p10_pick(grp: pd.DataFrame) -> str:
    """Pick the driver starting from grid position 10 (or nearest available)."""
    grp_sorted = grp.reindex(grp["grid_position"].sub(10).abs().sort_values().index)
    return grp_sorted["driver_id"].iloc[0]


def _naive_champ_p10_pick(grp: pd.DataFrame) -> str:
    """Pick the driver ranked 10th in the drivers' championship before this race."""
    champ_sorted = grp.sort_values("drv_champ_pos")
    # Find driver closest to championship position 10
    champ_sorted = grp.reindex(grp["drv_champ_pos"].sub(10).abs().sort_values().index)
    return champ_sorted["driver_id"].iloc[0]


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate models on 2025 season")
    parser.add_argument("--plots", action="store_true", help="Generate matplotlib charts")
    args = parser.parse_args()

    # ── load 2025 feature data ─────────────────────────────────────────────────
    eval_path = PROCESSED_DIR / f"features_{EVAL_YEAR}_{EVAL_YEAR}.parquet"
    if not eval_path.exists():
        logger.error(
            "2025 data not found at %s.\nRun scripts/02_build_dataset.py first.", eval_path
        )
        sys.exit(1)

    eval_df = pd.read_parquet(eval_path)
    n_races = eval_df[["year", "round"]].drop_duplicates().__len__()
    logger.info("Loaded 2025 eval data: %d rows, %d races", len(eval_df), n_races)

    # ── load trained models ───────────────────────────────────────────────────
    fitted = load_all()
    if not fitted:
        logger.error("No models found in models/.  Run scripts/03_train_models.py first.")
        sys.exit(1)
    logger.info("Loaded models: %s", list(fitted.keys()))

    # ── race-by-race evaluation ────────────────────────────────────────────────
    pick_rows: list[dict] = []

    for (yr, rnd), grp in eval_df.groupby(["year", "round"]):
        race_name = grp["race_name"].iloc[0]
        circuit   = grp["circuit_id"].iloc[0]

        # Ground truth map: driver_id → finish_position
        actual_map: dict[str, int] = dict(zip(grp["driver_id"], grp[TARGET_COL]))

        # Actual P10 driver
        actual_p10_drivers = grp[grp[TARGET_COL] == 10]["driver_id"].tolist()
        actual_p10 = actual_p10_drivers[0] if actual_p10_drivers else "N/A"

        # Max possible points anyone could have scored this race
        race_max_pts = max_possible_pts(actual_map)
        # Oracle always gets max — record once per race
        pick_rows.append({
            "year": yr, "round": rnd, "race_name": race_name, "circuit_id": circuit,
            "model": "oracle",
            "predicted": actual_p10,  # oracle always picks the best driver
            "actual_p10": actual_p10,
            "actual_pos": 10,         # oracle always hits it
            "fantasy_pts": race_max_pts,
            "regret": 0,
            "exact": int(race_max_pts == 25),
        })

        # Naive baselines
        baselines = {
            "naive_grid_p10":  _naive_grid_p10_pick(grp),
            "naive_champ_p10": _naive_champ_p10_pick(grp),
        }
        for bname, bpick in baselines.items():
            bpos = actual_map.get(bpick, 20)
            bpts = fantasy_pts(bpos)
            pick_rows.append({
                "year": yr, "round": rnd, "race_name": race_name, "circuit_id": circuit,
                "model": bname,
                "predicted": bpick,
                "actual_p10": actual_p10,
                "actual_pos": bpos,
                "fantasy_pts": bpts,
                "regret": calculate_regret(bpick, actual_map),
                "exact": int(bpos == 10),
            })

        # Model picks
        _, picks = predict_race(grp, fitted)

        for model_name, pick_driver in picks.items():
            actual_pos = actual_map.get(pick_driver, 20)
            pts    = fantasy_pts(actual_pos)
            regret = calculate_regret(pick_driver, actual_map)
            pick_rows.append({
                "year": yr, "round": rnd, "race_name": race_name, "circuit_id": circuit,
                "model": model_name,
                "predicted": pick_driver,
                "actual_p10": actual_p10,
                "actual_pos": actual_pos,
                "fantasy_pts": pts,
                "regret": regret,
                "exact": int(actual_pos == 10),
            })

    picks_df = pd.DataFrame(pick_rows)

    # ── save per-race picks ───────────────────────────────────────────────────
    picks_path = RESULTS_DIR / "eval_2025_picks.csv"
    picks_df.to_csv(picks_path, index=False)
    logger.info("Saved picks → %s", picks_path)

    # ── summary stats ─────────────────────────────────────────────────────────
    summary = (
        picks_df.groupby("model")
        .agg(
            n_races    =("fantasy_pts", "count"),
            total_pts  =("fantasy_pts", "sum"),
            avg_pts    =("fantasy_pts", "mean"),
            avg_regret =("regret",      "mean"),
            exact_p10  =("exact",       "sum"),
            within_2   =("actual_pos",  lambda x: (x.sub(10).abs() <= 2).sum()),
            regret_0   =("regret",      lambda x: (x == 0).sum()),   # races with zero regret (optimal picks)
        )
        .reset_index()
    )
    summary["exact_pct"]      = (summary["exact_p10"] / summary["n_races"] * 100).round(1)
    summary["within_2_pct"]   = (summary["within_2"]  / summary["n_races"] * 100).round(1)
    summary["optimal_pick_pct"] = (summary["regret_0"] / summary["n_races"] * 100).round(1)
    summary["avg_pts"]        = summary["avg_pts"].round(2)
    summary["avg_regret"]     = summary["avg_regret"].round(2)

    # Sort: oracle first, then by avg_pts desc, baselines at bottom
    def sort_key(model):
        if model == "oracle":        return -999
        if model.startswith("naive"): return 999
        return 0

    summary["_sort"] = summary["model"].apply(sort_key)
    summary = summary.sort_values(["_sort", "avg_pts"], ascending=[True, False]).drop(columns="_sort").reset_index(drop=True)

    summary_path = RESULTS_DIR / "eval_2025_summary.csv"
    summary.to_csv(summary_path, index=False)

    # ── print comparison table ────────────────────────────────────────────────
    display_cols = ["model", "avg_pts", "avg_regret", "exact_p10", "exact_pct", "within_2_pct", "optimal_pick_pct"]
    display = summary[display_cols].copy()
    display.columns = ["Model", "Avg Pts/Race", "Avg Regret", "Exact P10", "Exact %", "Within 2 %", "Optimal Pick %"]

    print(f"\n{SEPARATOR}")
    print("  2025 F1 SEASON — P10 PREDICTION EVALUATION")
    print(f"  Metric: Fantasy Points Regret  |  Races evaluated: {n_races}")
    print(f"{SEPARATOR}")
    print(display.to_string(index=False))
    print(f"{SEPARATOR}")
    print("  Regret = (Max possible pts that race) − (pts scored by model's pick)")
    print("  Regret = 0  → the model picked the optimal driver in hindsight")
    print("  Oracle = theoretical upper bound (always picks optimally)")
    print(f"{SEPARATOR}\n")

    logger.info("Saved summary → %s", summary_path)

    # ── per-circuit breakdown ──────────────────────────────────────────────────
    circ_df = (
        picks_df.groupby(["circuit_id", "model"])
        .agg(
            avg_pts    =("fantasy_pts", "mean"),
            avg_regret =("regret",      "mean"),
            n          =("fantasy_pts", "count"),
        )
        .reset_index()
    )
    circ_path = RESULTS_DIR / "eval_2025_by_circuit.csv"
    circ_df.to_csv(circ_path, index=False)
    logger.info("Saved circuit breakdown → %s", circ_path)

    # ── optional plots ────────────────────────────────────────────────────────
    if args.plots:
        _make_plots(picks_df, summary)


def _make_plots(picks_df: pd.DataFrame, summary: pd.DataFrame) -> None:
    import matplotlib.pyplot as plt
    import seaborn as sns

    plot_dir = RESULTS_DIR / "eval_2025_plots"
    plot_dir.mkdir(exist_ok=True)

    # Models only (exclude oracle for cleaner charts)
    model_picks = picks_df[~picks_df["model"].isin(["oracle"])]
    model_summary = summary[~summary["model"].isin(["oracle"])]

    # 1. Cumulative fantasy points over the season
    pivot = (
        model_picks.sort_values(["model", "round"])
        .groupby(["model", "round"])["fantasy_pts"].sum()
        .groupby(level=0).cumsum()
        .reset_index()
    )
    fig, ax = plt.subplots(figsize=(13, 6))
    for model, grp in pivot.groupby("model"):
        style = "--" if model.startswith("naive") else "-"
        lw = 1.5 if model.startswith("naive") else 2
        ax.plot(grp["round"], grp["fantasy_pts"], label=model, linestyle=style, lw=lw, marker="o", markersize=3)
    ax.set_xlabel("Race Round")
    ax.set_ylabel("Cumulative Fantasy Points")
    ax.set_title("Cumulative Fantasy Points – 2025 Season")
    ax.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(plot_dir / "cumulative_pts.png", dpi=150)
    plt.close()

    # 2. Avg Pts vs Avg Regret scatter (key comparison chart)
    fig, ax = plt.subplots(figsize=(9, 6))
    for _, row in model_summary.iterrows():
        color = "grey" if str(row["model"]).startswith("naive") else "steelblue"
        ax.scatter(row["avg_regret"], row["avg_pts"], s=120, color=color, zorder=3)
        ax.annotate(row["model"], (row["avg_regret"], row["avg_pts"]),
                    textcoords="offset points", xytext=(6, 4), fontsize=8)
    ax.set_xlabel("Avg Regret per Race (lower = better)")
    ax.set_ylabel("Avg Fantasy Pts per Race (higher = better)")
    ax.set_title("Model Performance: Avg Pts vs Avg Regret – 2025")
    ax.invert_xaxis()
    plt.tight_layout()
    plt.savefig(plot_dir / "pts_vs_regret.png", dpi=150)
    plt.close()

    # 3. Regret distribution per model (box plot)
    fig, ax = plt.subplots(figsize=(12, 5))
    order = model_summary["model"].tolist()
    sns.boxplot(data=model_picks, x="model", y="regret", order=order, ax=ax)
    ax.axhline(0, color="green", linestyle="--", lw=1, label="Zero regret (optimal)")
    ax.set_xlabel("Model")
    ax.set_ylabel("Regret per Race")
    ax.set_title("Regret Distribution per Model – 2025")
    ax.legend()
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.savefig(plot_dir / "regret_distribution.png", dpi=150)
    plt.close()

    logger.info("Plots saved to %s", plot_dir)


if __name__ == "__main__":
    main()
