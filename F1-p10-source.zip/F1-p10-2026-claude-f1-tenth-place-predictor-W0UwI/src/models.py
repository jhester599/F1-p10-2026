"""
Model definitions, training, persistence, and prediction.

Strategy
--------
We train two families of models on the 2010–2024 data:

  A) Regression  → predict finishing_position (1–20)
     Predict = driver whose predicted position is closest to 10.

  B) Classification → predict P(driver finishes 10th)
     Predict = driver with highest predicted P10 probability.

Models trained:
  1. Ridge Regression (regularised linear, baseline)
  2. Random Forest Regressor
  3. Gradient Boosting (XGBoost) Regressor
  4. LightGBM Regressor
  5. Random Forest Classifier  (is_p10 target)
  6. XGBoost Classifier        (is_p10 target)
  7. Ensemble Regressor        (average of RF + XGB + LGB predictions)

For each race we iterate over all 20 drivers, score each with the model, then
select the best candidate.
"""
from __future__ import annotations

import logging
import warnings
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, VotingRegressor
from sklearn.linear_model import Ridge
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))
from config import FEATURE_COLS, MODELS_DIR, TARGET_COL

logger = logging.getLogger(__name__)

try:
    from xgboost import XGBClassifier, XGBRegressor
    HAS_XGB = True
except ImportError:
    HAS_XGB = False
    logger.warning("xgboost not installed – XGB models will be skipped")

try:
    import lightgbm as lgb
    HAS_LGB = True
except ImportError:
    HAS_LGB = False
    logger.warning("lightgbm not installed – LGB models will be skipped")


# ── WeightedEnsemble ──────────────────────────────────────────────────────────

# CV-derived weights (higher = more influence).  Tune by re-running CV.
ENSEMBLE_WEIGHTS: dict[str, float] = {
    "xgb_clf": 4.0,   # best overall in CV; intentionally overweighted
    "rf_clf":  2.5,
    "lgb_reg": 2.0,
    "rf_reg":  1.0,
    "xgb_reg": 0.3,
    "ridge":   0.2,
}


# ── EV selection ──────────────────────────────────────────────────────────────

# Pre-computed fantasy points for finishing positions 1-20.
# Index 0 = position 1, index 19 = position 20.
import sys as _sys
_sys.path.insert(0, str(Path(__file__).parent.parent))
from config import FANTASY_POINTS as _FP
SCORING_VECTOR: np.ndarray = np.array(
    [_FP.get(abs(pos - 10), 0) for pos in range(1, 21)],
    dtype=float,
)

# Which classifier names use multi-class (finish_position) rather than binary (is_p10)
MULTICLASS_CLFS = {"xgb_clf", "rf_clf"}


def select_best_driver_by_ev(
    prob_matrix: np.ndarray,
    driver_ids: list[str],
    classes: list[int],
) -> tuple[str, np.ndarray]:
    """
    Select the driver with the highest Expected Value of fantasy points.

    Parameters
    ----------
    prob_matrix : ndarray, shape (n_drivers, n_classes)
        Output of ``classifier.predict_proba(X)``.
    driver_ids : list of str
        Driver identifiers in the same row order as prob_matrix.
    classes : list of int
        The ``classifier.classes_`` list — maps column index → finish position.

    Returns
    -------
    best_driver : str
        driver_id with highest EV.
    ev_scores : ndarray, shape (n_drivers,)
        EV score for every driver (fantasy pts in expectation).
    """
    # Build a (n_drivers, 20) matrix aligned to positions 1-20.
    # XGBClassifier is trained on 0-indexed classes (0-19); RF on 1-indexed (1-20).
    # We detect which convention is in use by checking the minimum class value.
    n_drivers = len(driver_ids)
    aligned = np.zeros((n_drivers, 20), dtype=float)
    class_offset = 1 if min(classes) == 0 else 0   # XGB → offset=1, RF → offset=0
    for col_idx, cls in enumerate(classes):
        pos = cls + class_offset                    # convert to 1-based finish position
        if 1 <= pos <= 20:
            aligned[:, pos - 1] = prob_matrix[:, col_idx]

    ev_scores = aligned @ SCORING_VECTOR           # (n_drivers,)
    best_idx  = int(np.argmax(ev_scores))
    return driver_ids[best_idx], ev_scores


class WeightedEnsemble:
    """
    Blends all base models using fixed weights derived from leave-one-season-out CV.

    Blending method
    ---------------
    * Classifiers  → use P(driver finishes 10th) directly.
    * Regressors   → convert predicted position to a proximity score:
                     1 / (1 + |predicted_pos − 10|)
    All per-race scores are min-max normalised before weighting so that
    models with different output scales contribute equally.
    """

    def __init__(self, base_models: dict[str, Any], weights: dict[str, float] | None = None):
        self.base_models = base_models
        self.weights = weights or ENSEMBLE_WEIGHTS

    def fit(self, X: np.ndarray, y: np.ndarray) -> "WeightedEnsemble":
        """Fit is a no-op: base models are already trained externally."""
        return self

    def _raw_scores(self, X: np.ndarray, driver_ids: list[str]) -> pd.DataFrame:
        """
        Return a DataFrame of normalised scores per driver per base model.

        - Multi-class classifiers (MULTICLASS_CLFS): score = EV of fantasy pts
        - Other classifiers: score = P(is_p10=1)
        - Regressors: score = 1 / (1 + |predicted_pos − 10|)
        All scores are min-max normalised per race before weighting.
        """
        scores: dict[str, np.ndarray] = {}

        for name, est in self.base_models.items():
            if name not in self.weights:
                continue

            is_multiclass_clf = name in MULTICLASS_CLFS
            is_clf = name.endswith("_clf")

            if is_multiclass_clf and hasattr(est, "predict_proba"):
                # EV: expected fantasy points across the full position distribution
                proba = est.predict_proba(X)
                classes = list(est.classes_)
                _, ev_scores = select_best_driver_by_ev(proba, driver_ids, classes)
                raw = ev_scores                          # already in fantasy-pts space
            elif is_clf and hasattr(est, "predict_proba"):
                proba = est.predict_proba(X)
                classes = list(est.classes_)
                idx = classes.index(1) if 1 in classes else -1
                raw = proba[:, idx]
            else:
                preds = est.predict(X).astype(float)
                raw = 1.0 / (1.0 + np.abs(preds - 10.0))

            # min-max normalise per race so all models contribute on same scale
            lo, hi = raw.min(), raw.max()
            norm = (raw - lo) / (hi - lo + 1e-9)
            scores[name] = norm

        return pd.DataFrame(scores, index=driver_ids)

    def score_drivers(
        self,
        race_features: pd.DataFrame,
        feature_cols: list[str],
    ) -> pd.Series:
        """
        Return a Series of weighted blended scores indexed by driver_id.
        Higher score → more likely to finish P10.
        """
        X = race_features[feature_cols].values.astype(float)
        driver_ids = race_features["driver_id"].tolist()

        score_df = self._raw_scores(X, driver_ids)

        weighted = pd.Series(0.0, index=driver_ids)
        total_w = 0.0
        for col in score_df.columns:
            w = self.weights.get(col, 0.0)
            weighted += w * score_df[col]
            total_w += w
        if total_w > 0:
            weighted /= total_w

        return weighted

    def predict(self, X: np.ndarray) -> np.ndarray:
        """sklearn-compatible predict: returns blended proximity scores."""
        driver_ids = [str(i) for i in range(len(X))]
        # Build a minimal DataFrame for score_drivers
        import pandas as _pd
        dummy = _pd.DataFrame({"driver_id": driver_ids})
        # We can't call score_drivers without feature_cols, so fall back to
        # a simple average of regressor predictions
        preds = []
        for name, est in self.base_models.items():
            if not name.endswith("_clf") and name in self.weights:
                preds.append(est.predict(X) * self.weights[name])
        if preds:
            w_sum = sum(self.weights[n] for n in self.base_models if not n.endswith("_clf") and n in self.weights)
            return np.sum(preds, axis=0) / max(w_sum, 1e-9)
        return np.full(len(X), 10.0)


# ── model catalogue ────────────────────────────────────────────────────────────

def _make_models() -> dict[str, Any]:
    """Return {name: unfitted sklearn-compatible estimator}."""
    models: dict[str, Any] = {
        "ridge": Pipeline([
            ("scaler", StandardScaler()),
            ("reg",    Ridge(alpha=10.0)),
        ]),
        "rf_reg": RandomForestRegressor(
            n_estimators=400,
            max_depth=8,
            min_samples_leaf=5,
            random_state=42,
            n_jobs=-1,
        ),
        "rf_clf": RandomForestClassifier(
            n_estimators=400,
            max_depth=8,
            min_samples_leaf=5,
            # Multi-class (positions 1-20): no binary class_weight
            random_state=42,
            n_jobs=-1,
        ),
    }

    if HAS_XGB:
        models["xgb_reg"] = XGBRegressor(
            n_estimators=500,
            max_depth=5,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            reg_alpha=1.0,
            reg_lambda=2.0,
            random_state=42,
            n_jobs=-1,
            verbosity=0,
        )
        models["xgb_clf"] = XGBClassifier(
            n_estimators=500,
            max_depth=5,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            # Multi-class: objective and num_class inferred from y in fit()
            random_state=42,
            n_jobs=-1,
            verbosity=0,
            eval_metric="mlogloss",
        )

    if HAS_LGB:
        models["lgb_reg"] = lgb.LGBMRegressor(
            n_estimators=500,
            num_leaves=31,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            reg_alpha=1.0,
            reg_lambda=2.0,
            random_state=42,
            n_jobs=-1,
            verbose=-1,
        )

    # Ensemble: average predictions from available regressors
    reg_list = [(k, models[k]) for k in ["rf_reg", "xgb_reg", "lgb_reg"] if k in models]
    if len(reg_list) >= 2:
        models["ensemble"] = VotingRegressor(estimators=reg_list, n_jobs=-1)

    return models


# ── training ───────────────────────────────────────────────────────────────────

def train_all(
    train_df: pd.DataFrame,
    force: bool = False,
) -> dict[str, Any]:
    """
    Fit all models on *train_df* and save to MODELS_DIR.

    Returns dict {model_name: fitted_estimator}.
    """
    X = train_df[FEATURE_COLS].values.astype(float)
    y_reg  = train_df[TARGET_COL].values.astype(float)          # finish_position 1-20 (regression)
    y_mc   = train_df[TARGET_COL].values.astype(int)            # finish_position 1-20 (multi-class)
    y_bin  = train_df["is_p10"].values.astype(int)              # kept for reference; no longer used

    fitted: dict[str, Any] = {}
    models = _make_models()

    for name, est in models.items():
        out_path = MODELS_DIR / f"{name}.joblib"
        if out_path.exists() and not force:
            logger.info("  %-14s → loading from disk", name)
            fitted[name] = joblib.load(out_path)
            continue

        is_multiclass_clf = name in MULTICLASS_CLFS
        is_clf = name.endswith("_clf")
        if is_multiclass_clf:
            # XGBClassifier requires 0-indexed integer classes (0–19);
            # RandomForestClassifier handles 1-indexed (1–20) natively.
            if name.startswith("xgb"):
                y = y_mc - 1  # shift to 0-indexed for XGBoost
            else:
                y = y_mc      # keep 1-indexed for scikit-learn classifiers
        elif is_clf:
            y = y_bin     # fallback for any other binary classifiers
        else:
            y = y_reg

        logger.info("  %-14s → training …", name)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            est.fit(X, y)

        joblib.dump(est, out_path)
        fitted[name] = est
        logger.info("             saved → %s", out_path)

    return fitted


def load_all() -> dict[str, Any]:
    """Load all saved models from MODELS_DIR."""
    fitted: dict[str, Any] = {}
    for p in MODELS_DIR.glob("*.joblib"):
        name = p.stem
        fitted[name] = joblib.load(p)
        logger.debug("Loaded %s", name)
    return fitted


# ── per-race prediction ────────────────────────────────────────────────────────

def _pick_p10(model_name: str, scores: pd.Series) -> str:
    """
    Given a series of model scores indexed by driver_id, return the driver_id
    most likely to finish 10th according to the model type.

    - Regressor: pick driver with predicted position closest to 10.
    - Classifier: pick driver with highest predicted probability.
    """
    is_clf = model_name.endswith("_clf")
    if is_clf:
        return scores.idxmax()
    else:
        return (scores - 10).abs().idxmin()


def predict_race(
    race_features: pd.DataFrame,
    fitted_models: dict[str, Any],
) -> pd.DataFrame:
    """
    Given a DataFrame of features for ONE race (one row per driver),
    return a DataFrame with columns:
      driver_id, constructor_id, grid_position,
      <model_name>_score,    (raw model output)
      <model_name>_pick,     (1 if this model picks this driver as P10)
      ensemble_pick (if available)

    Parameters
    ----------
    race_features : DataFrame
        Must contain FEATURE_COLS, driver_id, constructor_id, grid_position.
    fitted_models : dict
        Output of train_all() or load_all().
    """
    X = race_features[FEATURE_COLS].values.astype(float)
    out = race_features[["driver_id", "constructor_id", "grid_position"]].copy()

    picks: dict[str, str] = {}

    driver_ids = race_features["driver_id"].tolist()

    for name, est in fitted_models.items():
        # WeightedEnsemble has its own scoring path
        if isinstance(est, WeightedEnsemble):
            wscores = est.score_drivers(race_features, FEATURE_COLS)
            pick_driver = wscores.idxmax()
            out[f"{name}_score"] = race_features["driver_id"].map(wscores).values
            picks[name] = pick_driver
            out[f"{name}_pick"] = (race_features["driver_id"] == pick_driver).astype(int).values
            continue

        is_multiclass_clf = name in MULTICLASS_CLFS
        is_clf = name.endswith("_clf")

        if is_multiclass_clf and hasattr(est, "predict_proba"):
            # EV path: predict finish-position distribution, pick driver with max E[fantasy_pts]
            proba = est.predict_proba(X)                  # (n_drivers, n_classes)
            classes = list(est.classes_)
            pick_driver, ev_scores = select_best_driver_by_ev(proba, driver_ids, classes)
            scores = pd.Series(ev_scores, index=driver_ids)
        elif is_clf:
            if hasattr(est, "predict_proba"):
                proba = est.predict_proba(X)
                classes = list(est.classes_)
                idx = classes.index(1) if 1 in classes else -1
                scores = pd.Series(proba[:, idx], index=driver_ids)
            else:
                scores = pd.Series(est.predict(X), index=driver_ids)
            pick_driver = scores.idxmax()
        else:
            scores = pd.Series(est.predict(X), index=driver_ids)
            pick_driver = _pick_p10(name, scores)

        out[f"{name}_score"] = scores.values
        picks[name] = pick_driver
        out[f"{name}_pick"] = (race_features["driver_id"] == pick_driver).astype(int).values
        out[f"{name}_pick"] = (race_features["driver_id"] == pick_driver).astype(int).values

    out["vote_count"] = out[[c for c in out.columns if c.endswith("_pick")]].sum(axis=1)
    out = out.sort_values("vote_count", ascending=False).reset_index(drop=True)
    return out, picks


# ── feature importance ────────────────────────────────────────────────────────

def feature_importance_df(fitted_models: dict[str, Any]) -> pd.DataFrame:
    """
    Return a tidy DataFrame of feature importances for tree-based models.
    """
    rows = []
    for name, est in fitted_models.items():
        model = est
        # unwrap Pipeline
        if hasattr(model, "named_steps"):
            model = list(model.named_steps.values())[-1]
        if hasattr(model, "feature_importances_"):
            for feat, imp in zip(FEATURE_COLS, model.feature_importances_):
                rows.append({"model": name, "feature": feat, "importance": imp})
        elif hasattr(model, "estimators_"):
            # VotingRegressor
            for sub_name, sub_est in model.named_estimators_.items():
                if hasattr(sub_est, "feature_importances_"):
                    for feat, imp in zip(FEATURE_COLS, sub_est.feature_importances_):
                        rows.append({"model": f"ensemble/{sub_name}", "feature": feat, "importance": imp})
    return pd.DataFrame(rows)


# ── cross-validation helper ───────────────────────────────────────────────────

def leave_one_year_out_cv(
    feat_df: pd.DataFrame,
    years: list[int],
) -> pd.DataFrame:
    """
    For each year in *years*, train on all OTHER years and evaluate on
    that year.  Returns a DataFrame with MAE per model per year.
    """
    from src.scoring import evaluate_predictions

    cv_rows = []
    for eval_year in years:
        tr = feat_df[feat_df["year"] != eval_year]
        te = feat_df[feat_df["year"] == eval_year]

        fitted = train_all(tr, force=True)

        # per-race evaluation
        for race_id, race_grp in te.groupby(["year", "round"]):
            _, picks = predict_race(race_grp, fitted)
            actual_map = dict(zip(race_grp["driver_id"], race_grp[TARGET_COL]))
            for model_name, pick_driver in picks.items():
                actual_pos = actual_map.get(pick_driver, DNF_POSITION)
                from src.scoring import fantasy_pts
                cv_rows.append({
                    "cv_year":    eval_year,
                    "race_round": race_id[1],
                    "model":      model_name,
                    "picked":     pick_driver,
                    "actual_pos": actual_pos,
                    "fantasy_pts": fantasy_pts(actual_pos),
                })

    return pd.DataFrame(cv_rows)
